# Forex Bot via GitHub Actions

Automatyczny bot działający co 5 minut w chmurze GitHub Actions.